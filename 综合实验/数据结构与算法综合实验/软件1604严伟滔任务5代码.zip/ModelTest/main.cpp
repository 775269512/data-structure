#include <cstdio>
#include "model\LLKModel.h"

int main() {
	LLKModel model;
	model.init(12, 12, 5);
	Array2D<GirdBox>* map = model.getMap();


	//model.generateModelByDefault();
	model.generateModelWithBlankAround();
	int32_t a;
	model.dumpMemData("D:\\LLKGame0.txt");
	a = model.processTappedGirdBox(9, 12, NULL);
	a = model.processTappedGirdBox(9, 11, NULL);

	model.dumpMemData("D:\\LLKGame1.txt");

	model.disruptMap();

	model.dumpMemData("D:\\LLKGame2.txt");

	a = model.processTappedGirdBox(5, 3, NULL);
	a = model.processTappedGirdBox(6, 3, NULL);

	model.dumpMemData("D:\\LLKGame3.txt");

	return 0;
}
#ifndef _PATHS_H_
#define _PATHS_H_

#include <cstdint>
/*����·���ṹ��,�������·��,����ĸ���*/
#pragma pack(2)
typedef struct Paths
{
	int32_t pathNum;
	int32_t p1x, p1y;
	int32_t p2x, p2y;
	int32_t p3x, p3y;
	int32_t p4x, p4y;
}PathsInfo, Paths;
#pragma pack()

const int32_t INVALIDPATHSCODE = -1;
const int32_t VALIDPATHSCODE = 1;

void invalidatePaths(Paths*);
void validatePaths(Paths*);
void setPathNum(Paths*, int32_t);
void setP1(Paths*, int32_t, int32_t);
void setP2(Paths*, int32_t, int32_t);
void setP3(Paths*, int32_t, int32_t);
void setP4(Paths*, int32_t, int32_t);
#endif // !_PATHS_H_


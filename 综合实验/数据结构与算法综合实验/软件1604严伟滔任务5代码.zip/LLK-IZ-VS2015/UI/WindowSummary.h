#ifndef _WINDOWSUMMARY_H_
#define _WINDOWSUMMARY_H_

#include "window\GameUI.h"
#include "window\MainUI.h"
#include "window\RankingUI.h"
#include "window\SplashUI.h"

#endif // !_WINDOWSUMMARY_H_

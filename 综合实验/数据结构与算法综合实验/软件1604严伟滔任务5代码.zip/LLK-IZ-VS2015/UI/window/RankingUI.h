#ifndef _RANKINGUI_H_
#define _RANKINGUI_H_

#include <Windows.h>

void RegisterWindow_RankingUI(HINSTANCE hInstance);
HWND CreateWindow_RankingUI(HINSTANCE hInstance, int nCmdShow);

#endif // !_RANKINGUI_H_
#ifndef _GAMEUI_H_
#define _GAMEUI_H_

#include <Windows.h>

void RegisterWindow_GameUI(HINSTANCE hInstance);
HWND CreateWindow_GameUI(HINSTANCE hInstance, int nCmdShow);

#endif // !_GAMEUI_H_

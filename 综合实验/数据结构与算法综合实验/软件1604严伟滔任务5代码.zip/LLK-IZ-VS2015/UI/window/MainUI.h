#ifndef _MAINUI_H_
#define _MAINUI_H_

#include <Windows.h>

void RegisterWindow_MainUI(HINSTANCE hInstance);
HWND CreateWindow_MainUI(HINSTANCE hInstance, int nCmdShow);

#endif // !_MAINUI_H_
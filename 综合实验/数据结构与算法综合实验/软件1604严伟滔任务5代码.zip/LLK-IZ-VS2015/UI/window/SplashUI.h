#ifndef _SPLASHUI_H_
#define _SPLASHUI_H_

#include <Windows.h>

void RegisterWindow_SplashUI(HINSTANCE hInstance);
HWND CreateWindow_SplashUI(HINSTANCE hInstance, int nCmdShow);

#endif // !_SPLASHUI_H_
#ifndef _GRAPH_H_
#define _GRAPH_H_

#include<string>
#include<vector>

struct Vex
{
	int num;
	std::string name;
	std::string desc;
};

struct Edge
{
	int vex1;
	int vex2;
	int weight;
};

class CGraph
{
private:
	int m_aAdjMatrix[20][20];
	Vex m_aVexs[20];
	int m_nVexNum;
public:
	void init();
	void dfs(int n, int vis[], int path[]);
	int findSSSP(int i, int j, std::vector<int>& vis);
	bool InsertVex(Vex sVex);
	int FindEdge(int v, std::vector<Edge> &aEdge);
	bool InsertEdge(Edge sEdge);
	void printVex();
	void printEdge();
	Vex GetVex(int v);
	int FindEdge(int v, Edge aEdge[]);
	int getVexNum();
	int DesignPath();
};

#endif // !_GRAPH_H_
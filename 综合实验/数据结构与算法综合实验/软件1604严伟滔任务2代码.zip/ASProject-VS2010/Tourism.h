#ifndef _TOURISM_H_
#define _TOURISM_H_

#include<vector>

#include"Graph.h"

struct HeapNode {
	int d, u;
	bool operator<(const HeapNode& rhs)const {
		return d < rhs.d;
	}
};

void createGraph();
void print();
void GetSpotInfo();
void dijkstra(int d[], int i, int n, Vex v[], Edge fa[], std::vector<std::vector<Edge>> g);
void FindShortPath(int i, int j);
void TravelPath();
void designPath();

#endif // !_TOURISM_H_
#ifndef _COMMON_H_
#define _COMMON_H_

#include<string>
#include"Graph.h"
const int MAX_VERTEX_NUM = 20;
//����δ��ͨ·
const int INF = 999999;
const std::string VexFileName = "Vex.txt";
const std::string EdgeFileName = "Edge.txt";
void initTree(int root[], int n);
int find(int root[], int i);
void mergeNode(int root[], int i, int j);

#endif // !_COMMON_H

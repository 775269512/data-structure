#include <iostream>
#include <algorithm>
#include <string>
#include <vector>
#include <cstring>
#include <set>
#include <queue>

#include "common.h"
#include "Graph.h"
#include "Tourism.h"
using namespace std;
void CGraph::init()
{
	this->m_nVexNum = 0;
	memset(this->m_aAdjMatrix, 0, sizeof(this->m_aAdjMatrix));
}

void CGraph::dfs(int n, int vis[], int path[])
{
	if (n == m_nVexNum)
	{
		cout << m_aVexs[path[0]].name;
		for (int i = 1; i < m_nVexNum; ++i)
		{
			cout << "->" << m_aVexs[path[i]].name;
		}
		cout << endl;
		return;
	}
	else
	{
		for (int i = 0; i < m_nVexNum; ++i)
		{
			if (vis[i] == 0&&m_aAdjMatrix[path[n-1]][i]!=0)//�״η�������ͨ
			{
				vis[i] = 1;
				path[n] = i;
				dfs(n + 1, vis, path);
				vis[i] = 0;
			}
		}
	}
}


int CGraph::getVexNum()
{
	return m_nVexNum;
}
int CGraph::DesignPath()
{
	int m_num = this->m_nVexNum;
	int root[30];
	initTree(root, m_num);
	//start at Vex zero
	set<int>Vn;
	int ret = 0;
	Edge temp[30];
	int size= 0;
	Edge e;
	int min = INF;
	//��ѡ��һ����
	size=this->FindEdge(0, temp);
	for (int i = 0; i < size; ++i)
	{
		if (temp[i].weight < min)
		{
			e = temp[i];
			min = e.weight;
		}
	}
	Vn.insert(e.vex1);
	Vn.insert(e.vex2);
	//merge
	mergeNode(root,e.vex1, e.vex2);
	ret += e.weight;
	//start 
	cout << "����ƻ�����:" << endl;
	cout << this->m_aVexs[e.vex1].name << " - " << this->m_aVexs[e.vex2].name << "	" << e.weight <<"m"<< endl;
	set<int>::iterator iter;
	for (int i = 0; i < m_num - 2; ++i)
	{
		min = INF;
		for (iter = Vn.begin(); iter != Vn.end(); ++iter)
		{
			int vex1 = *iter;
			int fv1 = find(root, vex1);
			size = this->FindEdge(*iter, temp);
			for (int j = 0; j < size; ++j)
			{
				int vex2 = temp[j].vex2;
				int weight = temp[j].weight;
				int fv2 = find(root, vex2);
				if (fv1 != fv2 && weight < min)
				{
					min = weight;
					e = temp[j];
				}
			}
		}
		//merge
		mergeNode(root, e.vex1, e.vex2);
		//cout
		cout << this->m_aVexs[e.vex1].name << " - " << this->m_aVexs[e.vex2].name << "	" << e.weight <<"m"<< endl;
		Vn.insert(e.vex2);
		ret += e.weight;
	}
	cout << "�����·����̳���Ϊ:" << ret << endl;
	return 0;
}
//vis�洢��Դ�㵽Ŀ���֮�����·�ķ���·��
int CGraph::findSSSP(int i, int j,vector<int>& vis)
{
	Edge *fa = new Edge[m_nVexNum+1];
	int *d = new int[m_nVexNum];
	//void dijkstra(int i, int n,Vex v[], Edge fa[], vector<Edge> g[])
	//vector<Edge>* g = new vector<Edge>[m_nVexNum];
	vector<vector<Edge>> g;
	int num = m_nVexNum;
	while (num--)
	{
		vector<Edge> e;
		g.push_back(e);
	}
	for (int i = 0; i < m_nVexNum; ++i)
	{
		this->FindEdge(i, g[i]);
	}
	dijkstra(d,i, m_nVexNum, this->m_aVexs, fa, g);
	vis.clear();
	int p = j;
	while (p != i)
	{
		vis.push_back(p);
		Edge temp= fa[p];
		p = temp.vex1;
	}
	reverse(vis.begin(), vis.end());
	delete[] fa;
	int ret=d[j];
	delete[] d;
	return ret;
}
bool CGraph::InsertVex(Vex sVex)
{
	if (m_nVexNum == MAX_VERTEX_NUM)
	{
		cout << "InsertVex:���㳬���������!" << endl;
		return false;
	}
	this->m_aVexs[this->m_nVexNum++] = sVex;
	return true;
}

bool CGraph::InsertEdge(Edge sEdge)
{
	if (sEdge.vex1 < 0 || sEdge.vex1 >= m_nVexNum || sEdge.vex2 < 0 || sEdge.vex2 >= m_nVexNum)
	{
		cout << "InsertEdge:�±�Խ��" << endl;
		return false;
	}
	m_aAdjMatrix[sEdge.vex1][sEdge.vex2] = sEdge.weight;
	m_aAdjMatrix[sEdge.vex2][sEdge.vex1] = sEdge.weight;
	return true;
}

void CGraph::printVex()
{
	cout << "-----Vex----" << endl;
	for (int i = 0; i < m_nVexNum; ++i)
	{
		cout << m_aVexs[i].num << "-" << m_aVexs[i].name << endl;
	}
}
void CGraph::printEdge()
{
	cout << "----Edge----" << endl;
	for (int i = 0; i < m_nVexNum; ++i)
	{
		for (int j = i+1; j < m_nVexNum; ++j)
		{
			if (m_aAdjMatrix[i][j] != 0)
			{
				printf("(v%d,v%d) %d\n", i, j, m_aAdjMatrix[i][j]);
			}
		}
	}
}
Vex CGraph::GetVex(int v)
{
	return m_aVexs[v];
}

int CGraph::FindEdge(int v, Edge aEdge[])
{
	int k = 0;
	Edge edge;
	edge.vex1 = v;
	for (int i = 0; i < m_nVexNum; ++i)
	{
		if (m_aAdjMatrix[v][i] != 0)
		{
			edge.vex2 = i;
			edge.weight = m_aAdjMatrix[v][i];
			aEdge[k++] = edge;
		}
	}
    return k;
}
int CGraph::FindEdge(int v, vector<Edge>& aEdge)
{
	int k = 0;
	Edge edge;
	edge.vex1 = v;
	for (int i = 0; i < m_nVexNum; ++i)
	{
		if (m_aAdjMatrix[v][i] != 0)
		{
			edge.vex2 = i;
			edge.weight = m_aAdjMatrix[v][i];
			aEdge.push_back(edge);
		}
	}
	return aEdge.size();
}
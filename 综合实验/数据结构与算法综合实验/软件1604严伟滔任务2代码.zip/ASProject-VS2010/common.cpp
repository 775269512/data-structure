#include <iostream>
#include "common.h"
#include "Graph.h"
#include "Tourism.h"

using namespace std;
void initTree(int root[],int n)
{
	for (int i = 0; i < n; ++i)
	{
		root[i] = i;
	}
}
int find(int root[], int i)
{
	int r = root[i];
	while (root[r] != r)r = root[r];
	int j, k;
	j = i;
	while (j != r)
	{
		k = root[j];
		root[j] = r;
		j = k;
	}
	return r;
}
void mergeNode(int root[],int i, int j)
{
	int fi = find(root,i);
	int fj = find(root,j);
	if(fi!=fj)
	root[j] = fi;
}
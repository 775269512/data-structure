#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <queue>

#include "Tourism.h"
#include "Graph.h"
#include "common.h"

using namespace std;
CGraph m_Graph;
void createGraph()
{
	m_Graph.init();
	ifstream fin(VexFileName);
	int count;
	fin >> count;
	Vex vex;
	for (int i = 0; i < count; ++i)
	{
		fin >> vex.num >> vex.name >> vex.desc;
		m_Graph.InsertVex(vex);
	}
	fin.close();
	fin.open(EdgeFileName);
	Edge edge;
	while (fin >> edge.vex1 >> edge.vex2 >> edge.weight)
	{
		m_Graph.InsertEdge(edge);
	}
	return;
}
void print()
{
	m_Graph.printVex();
	m_Graph.printEdge();
}
void GetSpotInfo()
{
	cout << "��������Ҫ��ѯ�ľ�����" << endl;
	int i;
	cin >> i;
	Vex vex = m_Graph.GetVex(i);
	cout << vex.name << " " << vex.desc << endl;
	cout << "----�ܱ߾���-----" << endl;
	Edge aEdge[20];
	int k=m_Graph.FindEdge(i, aEdge);
	for (int j = 0; j < k; ++j)
	{
		Vex temp = m_Graph.GetVex(aEdge[j].vex2);
		cout << vex.name << "->" << temp.name<< " " << aEdge[j].weight << endl;
	}
	cout << endl;
	return;
}
void FindShortPath(int i, int j)
{
	vector<int>vis;
	vis.clear();
	int d=m_Graph.findSSSP(i, j,vis);
	cout <<"�����·������: "<< d << endl;
	cout << "Path:" << i;
	for (int k = 0; k < vis.size(); ++k)
	{
		cout << "->" << vis[k];
	}
	cout << endl;
}
/*����dΪ�洢�����ڵ㵽i����̾���
 *i,n�ֱ�Ϊ��ʼ�ڵ�ͽڵ�����
 *fa�Ǵ洢��i���ߵ�ǰһ�����������
 *g[i][j]��ʾ�ڵ�i�ĵ�j����
 */
void dijkstra(int d[],int i, int n,Vex v[], Edge fa[], vector<vector<Edge>> g)
{
	priority_queue<HeapNode> Q;
	for (int k = 0; k < n; ++k) d[k] = INF;
	d[i] = 0;
	int *done = new int[n + 1];
	memset(done, 0, sizeof(int)*(n+1));
	HeapNode temp;
	temp.d = 0;
	temp.u = i;
	Q.push(temp);
	while (!Q.empty())
	{
		HeapNode x = Q.top(); Q.pop();
		int u = x.u;
		if (done[u])continue;
		done[u] = 1;
		for (int k = 0; k < g[u].size(); ++k)
		{
			Edge &e = g[u][k];
			if (d[e.vex2] > d[u] + e.weight)
			{
				d[e.vex2] = d[u] + e.weight;
				fa[e.vex2] = g[u][k];
				HeapNode t;
				t.u = e.vex2;
				t.d = d[e.vex2];
				Q.push(t);
			}
		}
	}
	delete[] done;
}
void TravelPath()
{
	int i;
	cout << "���뵱ǰ��������" << endl;
	cin >> i;
	int *vis = new int[21];
	int *path = new int[21];
	path[0] = i;
	memset(vis, 0, sizeof(int) * 21);
	vis[i] = 1;
	m_Graph.dfs(1,vis,path);
	delete[] vis;
	delete[] path;
	return ;
}

void designPath()
{
	m_Graph.DesignPath();
}

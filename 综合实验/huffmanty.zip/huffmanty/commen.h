#ifndef COMMEN_H
#define COMMEN_H

#include <cstdio>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <memory>
#include <iostream>
#include <sstream>
#include <string>
#include <Windows.h>

using namespace std;

#endif // COMMEN_H
